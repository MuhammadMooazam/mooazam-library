def name():
    print("Mooazam")

def email():
    print("muhammadmoazam29@gmail.com")