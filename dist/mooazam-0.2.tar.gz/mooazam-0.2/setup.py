from setuptools import setup

setup(
    name='mooazam',
    version='0.2',
    description="This is Mooazam's package",
    long_description="This is Mooazam's package",
    author="Syed Muhammad Mooazam",
    author_email="muhammadmoazam29@gmail.com",
    packages=["mooazam"],
    install_requires=[]
)
